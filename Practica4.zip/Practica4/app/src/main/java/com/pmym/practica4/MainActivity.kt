package com.pmym.practica4

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.pmym.practica4.ui.theme.Practica4Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Practica4Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ProfileScreen()
                }
            }
        }
    }
}

@Composable
fun ProfileScreen() {
    Column {
        ProfileHeader(
            backClick = { /*TODO*/ },
            notificationClick = { /*TODO*/ },
            optionClick = { /*TODO*/ })
        ProfileInformation()
        ProfileDescription(modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 4.dp))
        ProfileAction(modifier = Modifier.padding(start = 16.dp, end = 16.dp))
        ProfileStoryHighlight(modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp))
        ProfilePost(modifier = Modifier.padding(top = 16.dp))
    }
}

@Composable
fun ProfileHeader(
    backClick: () -> Unit,
    notificationClick: () -> Unit,
    optionClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween) {
        Box {
            Row(verticalAlignment = Alignment.CenterVertically){
                IconButton(onClick = { /*TODO*/ }) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "flecha para volver")
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text(text = "jose_aguilera", fontWeight = FontWeight.Bold)
            }
        }
        Box {
            Row {
                IconButton(onClick = { /*TODO*/ }) {
                    Icon(imageVector = Icons.Default.Notifications, contentDescription = "notificaciones")
                }
                IconButton(onClick = { /*TODO*/ }) {
                    Icon(imageVector = Icons.Default.MoreVert, contentDescription = "opciones")
                }
            }
        }
    }
}

@Composable
fun ProfileInformation(
    modifier: Modifier = Modifier
) {
   Row(modifier = modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceAround) {
       Image(
           painter = painterResource(R.drawable.perfil),
           contentDescription = "Foto de perfil",
           modifier = Modifier
               .size(60.dp)
               .clip(CircleShape)
       )
       ProfileInformationItem(amount = 20, type = "Publicaciones")
       ProfileInformationItem(amount = 254, type = "Seguidores")
       ProfileInformationItem(amount = 370, type = "Seguidos")
   }
}
@Composable
private fun ProfileInformationItem(
    amount: Int,
    type: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = amount.toString(), fontWeight = FontWeight.Bold)
        Text(text = type)
    }
}

@Composable
fun ProfileDescription(
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier
        .fillMaxWidth()) {
        Text(text = "José Manuel Aguilera", fontWeight = FontWeight.Bold)
        Text(text = "Just living")
    }
}

@Composable
fun ProfileAction(
    modifier: Modifier = Modifier
) {
    Row(modifier = modifier.fillMaxWidth()) {
        ProfileButton(onClick = { /*TODO*/ }, text = "Siguiendo", modifier = Modifier.weight(1f))
        Spacer(modifier = Modifier.width(8.dp))
        ProfileButton(onClick = { /*TODO*/ }, text = "Mensaje", modifier = Modifier.weight(1f))
    }
}
@Composable
private fun ProfileButton(onClick: () -> Unit, text: String, modifier: Modifier = Modifier) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(Color.LightGray),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
    ) {
        Text(
            text = text,
            color = Color.Black
        )
    }
}

data class Story(val image: Int, val text: String)
@Composable
fun ProfileStoryHighlight(
    modifier: Modifier = Modifier
) {
    val stories = listOf(
        Story(R.drawable.destacadas, "Destacada 1"),
        Story(R.drawable.destacadas, "Destacada 2"),
        Story(R.drawable.destacadas, "Destacada 3"),
        Story(R.drawable.destacadas, "Destacada 4"),
        Story(R.drawable.destacadas, "Destacada 5"),
        Story(R.drawable.destacadas, "Destacada 6"),
        Story(R.drawable.destacadas, "Destacada 7"),
        Story(R.drawable.destacadas, "Destacada 8"),
        Story(R.drawable.destacadas, "Destacada 9"),
    )

    LazyRow(modifier = modifier) {
        items(stories) { story ->
            StoryItem(story = story)
            Spacer(modifier = Modifier.width(8.dp))
        }
    }
}
@Composable
private fun StoryItem(
    story: Story,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Image(
            painter = painterResource(story.image),
            contentDescription = "Imagen de historia destacada",
            modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
        )
        Text(text = story.text)
    }
}

data class Post(val image: Int)
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ProfilePost(
    modifier: Modifier = Modifier
) {
    val posts = listOf(
        Post(R.drawable.post01),
        Post(R.drawable.post02),
        Post(R.drawable.post03),
        Post(R.drawable.post04),
        Post(R.drawable.post05),
        Post(R.drawable.post06),
        Post(R.drawable.post07),
        Post(R.drawable.post08),
        Post(R.drawable.post09),
        Post(R.drawable.post01),
        Post(R.drawable.post02),
        Post(R.drawable.post03),
        Post(R.drawable.post04),
        Post(R.drawable.post05),
        Post(R.drawable.post06)
    )

    LazyVerticalGrid(columns = GridCells.Fixed(3)) {
        items(posts) { post ->
            PostItem(post = post, modifier = Modifier.padding(1.dp))
        }
    }
}
@Composable
private fun PostItem(
    post: Post,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier) {
        Image(
            painter = painterResource(post.image),
            contentDescription = "Publicación",
        )
    }
}

@Preview(showBackground = true)
@Composable
fun ProfileScreenPreview() {
    ProfileScreen()
}

@Preview(showBackground = true)
@Composable
fun ProfileHeaderPreview() {
    ProfileHeader({}, {}, {})
}

@Preview(showBackground = true)
@Composable
fun ProfileInformationPreview() {
    ProfileInformation()
}

@Preview(showBackground = true)
@Composable
fun ProfileDescriptionPreview() {
    ProfileDescription()
}

@Preview(showBackground = true)
@Composable
fun ProfileActionPreview() {
    ProfileAction()
}

@Preview(showBackground = true)
@Composable
fun ProfileStoryHighlightPreview() {
    ProfileStoryHighlight()
}

@Preview(showBackground = true)
@Composable
fun ProfilePostPreview() {
    ProfilePost()
}